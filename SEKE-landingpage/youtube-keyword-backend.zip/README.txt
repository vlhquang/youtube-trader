# YouTube Keyword Flask Backend

## Setup
1. pip install -r requirements.txt
2. Đặt `client_secret.json` vào cùng thư mục (tải từ Google Cloud Console)
3. python app.py

## Routes
- /login
- /oauth2callback
- /search?q=your_keyword
- /status
- /logout
